<?php
namespace ABNP;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Archive_BNP' ) ) {
    class Archive_BNP {

        private static $instance = null;
        private $rates_table_name;
        private $currencies_table_name;
        private $exchange_rates_uri = 'https://api.nbp.pl/api/exchangerates/tables/a';
        private static $archive_begin_date = '2002-01-01';
        private $archive_end_date = '2002-01-01';
        private $currencies_list = [];
        private $is_debug = true;
		public $today_date;
		public $base_currency = 'PLN';

        public function __construct() {
            global $wpdb;
            $this->rates_table_name = $wpdb->prefix . 'bnp_rates';
            $this->currencies_table_name = $wpdb->prefix . 'bnp_currencies';
            $this->today_date = date( 'Y-m-d', time() );
            $this->currencies_list = $this->get_currencies_list();
            $this->is_debug = false;

            register_activation_hook( AB_FILE_PATH, [ $this, 'install' ] );
            register_deactivation_hook( AB_FILE_PATH, [ $this, 'uninstall' ] );

            add_action( 'rest_api_init', [ $this, 'register_rest_routes' ] );
            add_action( 'init', [ $this, 'rates_update' ] );
            add_action( 'init', [ $this, 'archive_bnp_blocks_init' ] );
            add_filter( 'block_categories_all', [ $this, 'archive_bnp_blocks_category' ], 10, 2 );
        }

        public static function get_instance() {
            if ( null == self::$instance ) {
                self::$instance = new self;
            }
            return self::$instance;
        }
		
		public static function get_archive_begin_date() {
			return self::$archive_begin_date;
		}
		
		public static function get_archive_end_date() {
			return self::$today_date;
		}

        public function install() {
            global $wpdb;

            $charset_collate = $wpdb->get_charset_collate();

            $sql_1 = "CREATE TABLE $this->rates_table_name (
                id int NOT NULL AUTO_INCREMENT,
                currency_id int NOT NULL,
                exchange_rate float NOT NULL,
                exchange_date date NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY currency_date_idx (currency_id, exchange_date)
            ) $charset_collate;";

            $sql_2 = "CREATE TABLE $this->currencies_table_name (
                id int NOT NULL AUTO_INCREMENT,
                currency_name varchar(64) NOT NULL,
                currency_code varchar(4) NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY currency_code_idx (currency_code)
            ) $charset_collate;";

            require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
            dbDelta( $sql_1 . $sql_2 );

            $today = $this->get_bnp_today_currencies();
            foreach($today['rates'] as $currency){
                $wpdb->insert(
                    $this->currencies_table_name,
                    [
                        'currency_name' => $currency->currency,
                        'currency_code' => $currency->code,
                    ]
                );
            }
        }

        public function uninstall() {
            global $wpdb;
            $wpdb->query( "DROP TABLE IF EXISTS $this->rates_table_name" );
            $wpdb->query( "DROP TABLE IF EXISTS $this->currencies_table_name" );
            $this->ab_debug(false, AB_FILE_PATH . ' uninstall');
        }

        public function archive_bnp_blocks_init() {
            register_block_type( AB_DIR_PATH . '/blocks/currency-chart' );
            register_block_type( AB_DIR_PATH . '/blocks/last-rates' );
            register_block_type( AB_DIR_PATH . '/blocks/currency-converter' );
        }

        public function archive_bnp_blocks_category( $categories, $post ) {
            return [
                [
                    'slug'  => 'archive-bnp',
                    'title' => __('Archive BNP', 'archive-bnp'),
                ],
                ...$categories,
            ];
        }

        public function register_rest_routes() {
            register_rest_route( 'archive-bnp/v1', '/currencies', [
                'methods'  => 'GET',
                'callback' => [ $this, 'get_currencies' ],
                'permission_callback' => '__return_true',
            ]);

            register_rest_route( 'archive-bnp/v1', '/currencies-period/(?P<start_date>[0-9-]+)/(?P<end_date>[0-9-]+)/(?P<currency>[A-Z]+)', [
                'methods'  => 'GET',
                'callback' => [ $this, 'get_rates' ],
                'permission_callback' => '__return_true',
                'args' => [
                    'start_date' => [
                        'required' => true,
                        'validate_callback' => [ $this, 'is_valid_date_param' ],
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                    'end_date' => [
                        'required' => true,
                        'validate_callback' => [ $this, 'is_valid_date_param' ],
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                    'currency' => [
                        'required' => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                ],
            ]);
			
			register_rest_route( 'archive-bnp/v1', '/date-rates/(?P<date_rate>[0-9-]+)/(?P<currencies>[A-Z,]+)', [
                'methods'  => 'GET',
                'callback' => [ $this, 'get_date_rate' ],
                'permission_callback' => '__return_true',
                'args' => [
                    'date_rate' => [
                        'required' => true,
                        'validate_callback' => [ $this, 'is_valid_date_param' ],
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                    'currencies' => [
                        'required' => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                ],
            ]);
        }

        public function get_bnp_today_currencies() {
            $today = wp_remote_get($this->exchange_rates_uri);
            if( isset($today['response']['code']) && $today['response']['code'] === 200 ){
                $body = json_decode($today['body']);
                return [ 'date' => $body[0]->effectiveDate, 'rates' => $body[0]->rates ];
            }
            return false;
        }

        public function get_bnp_rates($start_date, $end_date) {
            $rates = wp_remote_get($this->exchange_rates_uri. '/' . $start_date . '/' . $end_date);
            if( isset($rates['response']['code']) && $rates['response']['code'] === 200 ){
                $body = json_decode( $rates['body'] );
                return $body;
            }
            return false;
        }

        public function insert_bnp_rates($bnp_rates) {
            global $wpdb;
            if( $bnp_rates ){
                $values = [];
                foreach($bnp_rates as $date_rates){
                    $effective_rates = $date_rates->rates;
                    foreach($effective_rates as $rate){
                        if(isset($this->currencies_list[$rate->code]['id'])){
                            $values[] = "(" . $this->currencies_list[$rate->code]['id'] . ", " . $rate->mid . ", '" . $date_rates->effectiveDate . "')";
                        }
                    }
                }
                if( empty( $values ) ){
                    return new \WP_Error( 'insert_bnp_rates', __( 'There aren\'t BNP rates for insert to local database.', 'archive-bnp' ), [ 'status' => 400 ] );
                } else{
                    $sql = "INSERT INTO $this->rates_table_name (currency_id, exchange_rate, exchange_date)
                            VALUES " . implode(',', $values) . "
                            ON DUPLICATE KEY UPDATE
                            exchange_rate = VALUES(exchange_rate),
                            exchange_date = VALUES(exchange_date);";
                    $wpdb->query($sql);
                    $this->ab_debug('========  Inserted values - ' . count($values) . ' ========');
                }
            }
        }

        public function rates_update(){
            $start_date = $this->get_last_rates();
            $end_date = $this->today_date;
            $start_date_obj = new \DateTime($start_date);
            $end_date_obj = new \DateTime();
            $end_date_obj->setTimezone(new \DateTimeZone('GMT'));
            $start_date_of_week = $start_date_obj->format('w');
            $end_date_of_week = $end_date_obj->format('w');
            $end_date_time = $end_date_obj->format('H');
            $dates_diff = $start_date_obj->diff($end_date_obj);
            if($start_date < $end_date){
                $this->ab_debug($start_date_of_week, 'start_date_of_week');
                $this->ab_debug($end_date_of_week, 'end_date_of_week');
                $this->ab_debug($end_date_time, 'end_date_time');
                $this->ab_debug($dates_diff->days, 'diff');
                if( $start_date_of_week == 5 && ( $end_date_of_week == 0 || $end_date_of_week == 6 ) && $dates_diff->days < 3 ){
                    $this->ab_debug('========  Nothing to update on weekend. ' . date('Y-d-m H:i:s') . ' ========');
                    return false;
                }
                if($end_date_time < 10 && ( $dates_diff->days == 1 || ( $dates_diff->days == 3 && $end_date_of_week == 1) ) ){
                    // TODO:
                    // BNP update the rates about 9.45AM GMT. Maybe need to adjust the time to check rates... 
                    $this->ab_debug('========  Nothing to update till 10.00 GMT in working date. ' . date('Y-d-m H:i:s') . ' ========');
                    return false;
                }
                $intervals = $this->get_dates_intervals( $start_date, $end_date );

                $this->ab_debug('========  Start insert rates. ' . date('Y-d-m H:i:s') . ' ========');
                for($i=0; $i<count($intervals); $i++){
                    $this->ab_debug('Start interval - ' . $intervals[$i]['start'] . ' End interval - ' . $intervals[$i]['end']);
                    $bnp_rates = $this->get_bnp_rates( $intervals[$i]['start'], $intervals[$i]['end'] );
                    $this->insert_bnp_rates($bnp_rates);
                }
                $this->ab_debug('========  Finish insert rates. ' . date('Y-d-m H:i:s') . ' ========');
            } else {
                $this->ab_debug('========  Nothing to update. ' . date('Y-d-m H:i:s') . ' ========');
            }
            
        }

        public function get_currencies() {
            if( !empty( $this->currencies_list ) ) {
                return new \WP_REST_Response( $this->currencies_list, 200 );
            } else {
                return new \WP_REST_Response( 'Currencies list is empty', 400 );
            }
            
        }

        public function get_rates( \WP_REST_Request $request ) {
            global $wpdb;
            
            $start_date = $request->get_param('start_date');
            $end_date = $request->get_param('end_date');
            $currency = $request->get_param('currency');

            $sql = $wpdb->prepare("SELECT exchange_rate as rate, exchange_date as date FROM $this->rates_table_name WHERE currency_id = %d AND ( exchange_date BETWEEN %s AND %s )", intval ($this->currencies_list["$currency"]["id"] ), $start_date, $end_date );
            $results = $wpdb->get_results( $sql, ARRAY_A );

            $response = [
				'archive_begin_date' => self::$archive_begin_date,
				'archive_end_date' => $this->today_date,
                'start_date' => $start_date,
                'end_date' => $end_date,
                'currency' => $currency,
                'currencies_list' => $this->currencies_list,
                'rates' => $results
            ];

            return new \WP_REST_Response( $response, 200 );
		}
        
		
		public function get_date_rate( \WP_REST_Request $request ) {
			global $wpdb;
			
			$date_rate = $request->get_param('date_rate');
            $currencies = $request->get_param('currencies');
			$sql = $wpdb->prepare("SELECT exchange_date as date FROM $this->rates_table_name WHERE exchange_date <= %s GROUP BY exchange_date DESC LIMIT %d", $date_rate, 2);
			$dates = $wpdb->get_results( $sql, ARRAY_A );
			$dates_to_show = [];
			foreach($dates as $item){
				$dates_to_show[] = $item['date'];
			}
			$sql = $wpdb->prepare("
			SELECT r.exchange_rate as rate, r.exchange_date as date, c.currency_code 
			FROM $this->rates_table_name as r
			LEFT JOIN $this->currencies_table_name as c ON r.currency_id = c.id
			WHERE r.exchange_date IN ('" . implode("','", $dates_to_show) . "')
			AND c.currency_code IN ('" . str_replace("," , "','", $currencies) . "')"); 
			$rates = $wpdb->get_results( $sql, ARRAY_A );

			$response = [
				'date_rate' => $date_rate,
				'currencies' => $currencies,
				'dates_to_show' => $dates_to_show,
				'rates' => $rates
			];
			
			return new \WP_REST_Response( $response, 200 );
		}

        public function get_currencies_list(){
            global $wpdb;
            if( $this->table_exists($this->currencies_table_name) ) {
                $sql = "SELECT * FROM $this->currencies_table_name";
                $result = $wpdb->get_results($sql, ARRAY_A);
                $currencies_list = array_map( function($item) {
                    return [ $item['currency_code'] => [ 'id' => $item['id'], 'name' => $item['currency_name'] ] ];
                }, $result);
                $currencies_list = array_reduce($currencies_list, 'array_merge', []);
                return $currencies_list;
            }
            return new \WP_Error( 'archive_bnp_table_error', __( $this->currencies_table_name . ' table doesn\'t exist.', 'archive-bnp' ), [ 'status' => 400 ] );
        }

        public function get_last_rates(){
            global $wpdb;
            $sql = $wpdb->prepare("SELECT exchange_date FROM $this->rates_table_name WHERE currency_id = %d ORDER BY exchange_date DESC LIMIT 1", $this->currencies_list['USD']['id']);
            $result = $wpdb->get_var($sql);
            if($result){
                return $result;
            }
            return self::$archive_begin_date;
        }

        public function get_dates_intervals($start_date, $end_date) {
            $start = new \DateTime($start_date);
            $end = new \DateTime($end_date);
            $intervals = [];
        
            while ($start < $end) {
                $interval_end = clone $start;
                $interval_end->modify('+93 days');

                if ($interval_end > $end) {
                    $interval_end = $end;
                }

                $intervals[] = [
                    'start' => $start->format('Y-m-d'),
                    'end' => $interval_end->format('Y-m-d')
                ];

                $start = $interval_end->modify('+1 day');
            }
        
            return $intervals;
        }

        function is_valid_date_param( $param, $request, $key ) {

            $wp_error_code = 'invalid_' . $key;
            $error_label = str_replace( '_', ' ', $key);
            $start_date_param = $request->get_param('start_date');
            $end_date_param = $request->get_param('end_date');

            if( !(bool)strtotime($param) ) {
                return new \WP_Error( $wp_error_code, __( 'The ' . $error_label . ' parameter is invalid.', 'archive-bnp' ), [ 'status' => 400 ] );
            } elseif( self::$archive_begin_date > $param ){
                return new \WP_Error( $wp_error_code, __( 'The ' . $error_label . ' can\'t be less than ' . self::$archive_begin_date . '.', 'archive-bnp' ), [ 'status' => 400 ] );
            } elseif( $this->today_date < $param ){
                return new \WP_Error( $wp_error_code, __( 'The ' . $error_label . ' can\'t be more than ' . $this->today_date . '.', 'archive-bnp' ), [ 'status' => 400 ] );
            } elseif( $this->archive_end_date > $param ){
                return new \WP_Error( $wp_error_code, __( 'The ' . $error_label . ' can\'t be less than ' . $this->archive_end_date . '.', 'archive-bnp' ), [ 'status' => 400 ] );
            } elseif( $start_date_param > $end_date_param ){
                return new \WP_Error( $wp_error_code, __( 'The start date can\'t be more than end date', 'archive-bnp' ), [ 'status' => 400 ] );
            }

            return true;
            
        }

        public function table_exists( $table ) {
            global $wpdb;
            $table_exists = $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" );
            if ( \is_wp_error( $table_exists ) || \is_null( $table_exists ) ) {
                return false;
            }
            return true;
        }

        public function get_currency_rates( $rates, $date1, $date2, $currency ){
            $rate1 = 0;
            $rate2 = 0;
            foreach( $rates as $row ){
                if( $row['currency_code'] == $currency ) {
                    if( $row['date'] == $date1 ) {
                        $rate1 = $row['rate'];
                    }
                    if( $row['date'] == $date2 ) {
                        $rate2 = $row['rate'];
                    }
                    if($rate1 > 0 && $rate2 > 0) {
                        break;
                    }
                }
            }
            if($rate1 > 0 && $rate2 > 0) {
                return [ 'rate1' => $rate1, 'rate2' => $rate2, 'diff' => number_format( round( ($rate1 - $rate2) / $rate2 * 100, 3), 3 ) ];
            }
            return false;
        }
        
        public function get_conversion_rates( $rates, $date ){
            $conversions['PLN'] = 1;
            foreach( $rates as $rate ){
                if( $rate['date'] == $date ){
                    $conversions[$rate['currency_code']] = round( 1 / $rate['rate'], 4 );
                }
            }
            return $conversions;
        }

        private function ab_debug($item, $text = ''){
            if( $this->is_debug ){
                if(!empty($text)) $text = $text . "\n";
                file_put_contents( AB_DIR_PATH . '/debug.log', "\n" . $text, FILE_APPEND);
                file_put_contents( AB_DIR_PATH . '/debug.log', print_r($item, true), FILE_APPEND);
            }
        }
    }

    Archive_BNP::get_instance();
}
