<?php return array('dependencies' => array(), 'version' => 'ef287db0f49d2679d8a9');
