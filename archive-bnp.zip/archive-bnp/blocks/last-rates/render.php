<?php
/**
 * @see https://github.com/WordPress/gutenberg/blob/trunk/docs/reference-guides/block-api/block-metadata.md#render
 */

$date_rate = explode('T', $attributes['rateDate'])[0];
$currencies = implode(',', $attributes['selectedCurrencies']);
$bnp_archive = new \ABNP\Archive_BNP();
if( strtotime( $date_rate ) > strtotime( $bnp_archive->today_date ) ){
	$date_rate = $bnp_archive->today_date;
}
$api_url = get_rest_url() . 'archive-bnp/v1/date-rates/' . $date_rate . '/' . $currencies;
$wp_http = new WP_Http();
$request = $wp_http->request($api_url, ['sslverify' => false]);
$body = json_decode($request['body'], true);

?>
<div <?= get_block_wrapper_attributes() ?>>
	<h2><?= $bnp_archive->base_currency . __( ' Exchange Rates, ', 'archive-bnp' ) . $date_rate . '.' ?></h2>
</div>

<table class="current-rates">
	<tr>
		<th>&nbsp;</th>	
		<th><?= $body['dates_to_show'][0] ?></th>
		<th><?= $body['dates_to_show'][1] ?></th>
		<th>&nbsp;</th>
	</tr>
	<?php 
	foreach($attributes['selectedCurrencies'] as $currency) { 
		$currency_rates = $bnp_archive->get_currency_rates( $body['rates'], $body['dates_to_show'][0], $body['dates_to_show'][1], $currency );
		$row_class = 'diff-arrow-up';
		$precision = in_array($currency, ['HUF', 'JPY', 'ISK', 'CLP', 'IDR', 'INR', 'KRW']) ? 6 : 4;
		if($currency_rates['diff'] < 0){
			$row_class = 'diff-arrow-down';
		}
	?>
		<tr>
			<td><?= $currency ?></td>
			<td><?= number_format( $currency_rates['rate1'], $precision ) ?></td>
			<td><?= number_format( $currency_rates['rate2'], $precision ) ?></td>
			<td><span class="<?= $row_class ?>"><?= $currency_rates['diff'] ?>%</span></td>
		</tr>
	<?php } ?>
</table>