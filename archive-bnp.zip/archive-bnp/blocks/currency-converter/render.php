<?php
/**
 * @see https://github.com/WordPress/gutenberg/blob/trunk/docs/reference-guides/block-api/block-metadata.md#render
 */

$currencies = implode(',', $attributes['selectedCurrencies']);
$bnp_archive = new \ABNP\Archive_BNP();
$date_rate = $bnp_archive->today_date;

$api_url = get_rest_url() . 'archive-bnp/v1/date-rates/' . $date_rate . '/' . $currencies;
$wp_http = new WP_Http();
$request = $wp_http->request($api_url, ['sslverify' => false]);
$body = json_decode($request['body'], true);
$rates = $bnp_archive->get_conversion_rates( $body['rates'], $body['dates_to_show'][0] );
wp_localize_script( 'archive-bnp-blocks-currency-converter-view-script', 'conversionData', $rates );

?>
<div <?= get_block_wrapper_attributes() ?>>
	<h2><?=  __( ' Exchange Converter, ', 'archive-bnp' ) . $date_rate . '.' ?></h2>
</div>

<div id="converter-rates"></div>
