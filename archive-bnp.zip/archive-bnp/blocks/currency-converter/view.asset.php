<?php return array('dependencies' => array('react', 'react-dom', 'wp-element'), 'version' => '05f5ffaafe94afc59a75');
