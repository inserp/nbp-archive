<?php return array('dependencies' => array('moment'), 'version' => '7c3c67ef74561589e32e');
