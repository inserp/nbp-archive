<?php
/**
 * Plugin Name:        NBP archive
 * Description:        NBP exchange rates archive.
 * Author:             Ihar Dounar
 * Author URI:         https://www.linkedin.com/in/ihar-dounar/
 * Requires at least:  6.2
 * Requires PHP:       7.4
 * Text Domain:        archive-bnp
 * Version:            1.0.1
 * License:            GPL-2.0-or-later
 *
 * @package         archive-bnp
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*************************************************************************
* Constants
************************************************************************/
define( 'AB_DIR_PATH', __DIR__ );
define( 'AB_DIR_URL', plugin_dir_url(__FILE__) );
define( 'AB_FILE_PATH', __FILE__ );

/*************************************************************************
 * Requires - core
 ************************************************************************/
require_once AB_DIR_PATH . '/inc/archive-bnp-class.php';