<?php return array('dependencies' => array('moment'), 'version' => '1427d26af88fefaef0c6');
